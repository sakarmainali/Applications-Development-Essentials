import React, { useEffect, useState } from 'react';

import Input from '../../shared/components/FormElements/Input';
import Button from '../../shared/components/FormElements/Button';
import ErrorModal from '../../shared/components/UIElements/ErrorModal';
import LoadingSpinner from '../../shared/components/UIElements/LoadingSpinner';
import './Landing.css';

const Landing = () => {
  



    return (
      <React.Fragment>
      <img src={'http://localhost:5000/uploads/images/Default3.png'} alt="WELCOME" class="center"/>
      
     
   

            

        

    

          </React.Fragment>
    );
};


export default Landing;
