import React, { useEffect, useState } from 'react';

import SummaryList from '../components/SummaryList';
import ErrorModal from '../../shared/components/UIElements/ErrorModal';
import LoadingSpinner from '../../shared/components/UIElements/LoadingSpinner';
import { useHttpClient } from '../../shared/hooks/http-hook';

const Users = () => {
  const { isLoading, error, sendRequest, clearError } = useHttpClient();
  const [loadedSummaries, setLoadedSummaries] = useState();

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const responseData = await sendRequest(
          'http://localhost:5000/api/summary'
        );

        setLoadedSummaries(responseData.summaries);
        console.log("Agiannanana");
        console.log(responseData.summaries);

      } catch (err) {}
    };
    fetchUsers();
  }, [sendRequest]);

  return (
    <React.Fragment>
      <ErrorModal error={error} onClear={clearError} />
      {isLoading && (
        <div className="center">
          <LoadingSpinner />
        </div>
      )}
      {!isLoading && loadedSummaries && <SummaryList items={loadedSummaries} />}
    </React.Fragment>
  );
};

export default Users;
