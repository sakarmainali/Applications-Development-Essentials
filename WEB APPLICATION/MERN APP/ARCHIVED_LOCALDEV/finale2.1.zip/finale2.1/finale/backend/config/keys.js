module.exports={
    googleClientID:'187378869172-knu7fo91uclfmek7ck7v4qpc9htrpqkr.apps.googleusercontent.com' ,
    googleClientSecret:'c3erhGDg6UpL1_gpNH3FKdRA',
    mongoURI:'mongodb+srv://debugger:debugger@sakacluster-0i4qj.mongodb.net/merndum?retryWrites=true&w=majority',
    cookiekey:'adsfjbkbkjbdsfdsfdf',
    mailerid:'bookmin.email@gmail.com',
    mailerkey:'nimkoob465'
};

